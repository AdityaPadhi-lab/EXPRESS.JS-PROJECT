// index.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Middleware to parse URL-encoded bodies (from HTML forms)
app.use(express.urlencoded({ extended: true }));

// Path to the tasks file (persistent storage)
const tasksFilePath = path.join(__dirname, 'tasks.json');

// Utility function: read tasks from tasks.json (returns an array)
function readTasks() {
  try {
    if (fs.existsSync(tasksFilePath)) {
      const data = fs.readFileSync(tasksFilePath, 'utf8');
      return data ? JSON.parse(data) : [];
    }
    return [];
  } catch (err) {
    console.error("Error reading tasks:", err);
    return [];
  }
}

// Utility function: write tasks to tasks.json
function writeTasks(tasks) {
  try {
    fs.writeFileSync(tasksFilePath, JSON.stringify(tasks, null, 2));
  } catch (err) {
    console.error("Error writing tasks:", err);
  }
}

// GET route: Display the home page with tasks loaded from tasks.json
app.get('/', (req, res) => {
  const tasks = readTasks();
  console.log("Loaded tasks:", tasks);  // Debug: log loaded tasks
  res.render('index', { files: tasks });
});

// POST route: Add a new task (save to tasks.json) and then redirect to home
app.post('/create', (req, res) => {
  console.log("Received POST data:", req.body);  // Debug: log form input

  const title = req.body.title;
  const details = req.body.details;

  if (!title || !details) {
    return res.send("Both title and details are required.");
  }

  // Create a new task object
  const newTask = {
    title: title,
    details: details,
    link: '/task/' + Date.now()  // Dummy link based on timestamp
  };

  // Read the existing tasks, add the new task, then write back to file
  const tasks = readTasks();
  tasks.push(newTask);
  writeTasks(tasks);

  console.log("Task saved successfully:", newTask); // Debug: log new task
  res.redirect('/');
});

// POST route: Delete an individual task (using the task index)
app.post('/delete', (req, res) => {
  const index = parseInt(req.body.index, 10);
  let tasks = readTasks();
  if (!isNaN(index) && index >= 0 && index < tasks.length) {
    tasks.splice(index, 1);
    writeTasks(tasks);
    console.log(`Deleted task at index ${index}`);
  }
  res.redirect('/');
});

// POST route: Clear all tasks from the server
app.post('/clear', (req, res) => {
  writeTasks([]);
  console.log("All tasks cleared.");
  res.redirect('/');
});
  
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}...`);
});
